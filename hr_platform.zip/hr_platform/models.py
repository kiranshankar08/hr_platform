from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class SectionManager(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)

class DepartmentManager(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    reports_to_id = db.Column(db.Integer, db.ForeignKey('section_manager.id'))
    reports_to = db.relationship('SectionManager')

class EmployeeDesignation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    reports_to_id = db.Column(db.Integer, db.ForeignKey('department_manager.id'))
    reports_to = db.relationship('DepartmentManager')

class Employee(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    dob = db.Column(db.String(10))         # e.g., '2000-06-28'
    doj = db.Column(db.String(10))         # e.g., '2021-06-28'
    designation = db.Column(db.String(50))
    department = db.Column(db.String(50))
    # add other fields if required

    def __repr__(self):
        return f'<Employee {self.name}>'
