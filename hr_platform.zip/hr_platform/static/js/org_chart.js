document.addEventListener("DOMContentLoaded", () => {
  fetch("/data/org_hierarchy.json")
    .then(res => res.json())
    .then(data => renderOrgChart(data));
});

function createNode(name, children = []) {
  const node = document.createElement("div");
  node.className = "node";
  node.innerHTML = `<div class="box">${name}</div>`;

  if (children.length > 0) {
    const childContainer = document.createElement("div");
    childContainer.className = "children";
    children.forEach(child => {
      if (typeof child === 'string') {
        childContainer.appendChild(createNode(child));
      } else {
        const [key, val] = Object.entries(child)[0];
        childContainer.appendChild(createNode(key, val));
      }
    });
    node.appendChild(childContainer);
  }

  return node;
}

function renderOrgChart(data) {
  const container = document.getElementById("orgTree");

  const topHierarchy = {
    "Managing Director": [
      { "Board of Directors": [
        { "General Manager": Object.entries(data["General Manager"] || {}).map(([k,v]) => ({ [k]: v })) },
        { "Operational Manager": Object.entries(data["Operational Manager"] || {}).map(([k,v]) => ({ [k]: v })) }
      ]}
    ]
  };

  const [rootName, rootChildren] = Object.entries(topHierarchy)[0];
  const rootNode = createNode(rootName, rootChildren);
  container.appendChild(rootNode);
}
