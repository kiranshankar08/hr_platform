from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from routes.admin import admin_bp
from models import db

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# ✅ Configure the SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///hr.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# ✅ Initialize DB
db.init_app(app)

# ✅ Create tables if not exist
with app.app_context():
    db.create_all()

# ✅ Register blueprint
app.register_blueprint(admin_bp, url_prefix='/')

@app.route('/')
def home():
    return render_template('landing.html')

if __name__ == '__main__':
    app.run(debug=True)
