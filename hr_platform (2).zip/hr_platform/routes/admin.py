from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from models import db, SectionManager, DepartmentManager, EmployeeDesignation, Employee
import os, json, smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from collections import Counter

admin_bp = Blueprint('admin', __name__, template_folder='../templates')

# ✅ File paths
EMPLOYEE_FILE = 'employees.json'
PROJECT_FILE = 'projects.json'
CUSTOMER_FILE = 'customers.json'
os.makedirs('static/uploaded_policies', exist_ok=True)

# ✅ Ensure files exist
for file_path, default_data in [
    (EMPLOYEE_FILE, []),
    (PROJECT_FILE, []),
    (CUSTOMER_FILE, [])
]:
    if not os.path.exists(file_path):
        with open(file_path, 'w') as f:
            json.dump(default_data, f, indent=2)

# ✅ Utility

def get_next_employee_code():
    with open(EMPLOYEE_FILE, 'r') as f:
        employees = json.load(f)
    return f"CAPL-STF-{str(len(employees) + 1).zfill(3)}"

# ✅ Auth routes
@admin_bp.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        if request.form.get('email') == 'admin@hr.com' and request.form.get('password') == 'admin123':
            session['admin'] = True
            return redirect(url_for('admin.admin_dashboard'))
        flash('Invalid credentials', 'danger')
    return render_template('admin_login.html')

@admin_bp.route('/admin-dashboard')
def admin_dashboard():
    if not session.get('admin'):
        return redirect(url_for('admin.admin_login'))
    return render_template('admin_dashboard.html')

# ✅ Organisation Pages
@admin_bp.route('/organisation')
def organisation():
    return render_template('organisation_detail.html')

@admin_bp.route('/admin-policies')
def admin_policies():
    return render_template('admin_policies.html')

# ✅ Employees
@admin_bp.route('/add-employee', methods=['GET', 'POST'])
def add_employee():
    if request.method == 'POST':
        data = {key: request.form[key] for key in request.form}
        with open(EMPLOYEE_FILE, 'r+') as f:
            employees = json.load(f)
            employees.append(data)
            f.seek(0)
            f.truncate()
            json.dump(employees, f, indent=2)
        flash('✅ Employee added!', 'success')
        return redirect(url_for('admin.view_employees'))

    code = get_next_employee_code()
    return render_template('add_employee.html', employee_code=code)

@admin_bp.route('/view-employees')
def view_employees():
    with open(EMPLOYEE_FILE, 'r') as f:
        employees = json.load(f)
    return render_template('view_employees.html', employees=employees)

# ✅ Hierarchy
@admin_bp.route('/organisation-hierarchy')
def organisation_hierarchy():
    return render_template('organisation_hierarchy.html')

@admin_bp.route('/org-chart')
def org_chart():
    return render_template('org_chart.html')

# ✅ Projects
@admin_bp.route('/customer-setup', methods=['GET', 'POST'])
def customer_setup():
    return render_template('customer_setup.html')

@admin_bp.route('/create-project', methods=['GET', 'POST'])
def create_project():
    return render_template('create_project.html')

# ✅ Task Management
@admin_bp.route('/task-assign', methods=['GET', 'POST'])
def task_assign():
    return render_template('assign_task.html')

@admin_bp.route('/task-reports')
def task_reports():
    return render_template('task_reports.html')

# ✅ Attendance
@admin_bp.route('/attendance-track')
def attendance_track():
    return render_template('attendance_track.html')

@admin_bp.route('/attendance-report')
def attendance_report():
    return render_template('attendance_report.html')

# ✅ Special Days API
@admin_bp.route('/api/special-days')
def get_special_days():
    today = datetime.today()
    today_mmdd = today.strftime('%m-%d')
    current_year = today.year

    special = {"birthdays": [], "anniversaries": []}

    if os.path.exists(EMPLOYEE_FILE):
        with open(EMPLOYEE_FILE, 'r') as f:
            employees = json.load(f)

        for emp in employees:
            dob = emp.get('dob')
            doj = emp.get('doj')
            name = emp.get('name', 'Employee')

            if dob:
                try:
                    if datetime.strptime(dob, '%Y-%m-%d').strftime('%m-%d') == today_mmdd:
                        special['birthdays'].append(name)
                except:
                    pass

            if doj:
                try:
                    doj_date = datetime.strptime(doj, '%Y-%m-%d')
                    if doj_date.strftime('%m-%d') == today_mmdd:
                        years = current_year - doj_date.year
                        if years > 0:
                            special['anniversaries'].append({"name": name, "years": years})
                except:
                    pass

    return jsonify(special)
